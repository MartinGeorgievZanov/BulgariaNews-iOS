//
//  AddedToFav.h
//  BulgariaNews
//
//  Created by Makros on 5/26/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@interface AddedToFav : NSManagedObject

@property (nonatomic) int id;

@end
