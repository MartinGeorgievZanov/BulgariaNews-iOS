//
//  CategoryNamesViewController.h
//  BulgariaNews_iOS
//
//  Created by Makros on 3/11/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KMXMLParser.h"

@interface CategoryNamesViewController : UITableViewController <KMXMLParserDelegate>{
    
    int check;
    NSString *categoryName;
}

@property (nonatomic) int check;
@property (nonatomic) NSString *categoryName;

@property (strong, nonatomic) NSMutableArray *parseResults;

@end
