//
//  FavoritesViewController.h
//  BulgariaNews_iOS
//
//  Created by Makros on 3/11/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsObject.h"

extern NSString * url;

@class FavoritesCell;

@interface FavoritesViewController : UITableViewController <NSFetchedResultsControllerDelegate>
{
@private
    NSFetchedResultsController *_fetchedResultsController;
    NSManagedObjectContext *_managedObjectContext;
}
@property (nonatomic, retain) NSFetchedResultsController *fetchedResultsController;
@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;
@property (strong, nonatomic) NSMutableArray *parseResult;

@property (nonatomic) IBOutlet UIButton * backButtonFavorites;

- (void)configureCell:(FavoritesCell *)cell atIndexPath:(NSIndexPath *)indexPath;

@end
