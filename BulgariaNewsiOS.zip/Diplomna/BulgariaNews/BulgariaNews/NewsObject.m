//
//  NewsObject.m
//  BulgariaNews_iOS
//
//  Created by Makros on 4/15/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import "NewsObject.h"

@implementation NewsObject

@dynamic title;
@dynamic news;
@dynamic newsDescription;
@dynamic dateEntered;
@dynamic image;
@dynamic category;
@dynamic imageLink;

@end

@implementation ImageToDataTransformer

+ (BOOL)allowsReverseTransformation {
	return YES;
}

+ (Class)transformedValueClass {
	return [NSData class];
}

- (id)transformedValue:(id)value {
	NSData *data = UIImagePNGRepresentation(value);
	return data;
}

- (id)reverseTransformedValue:(id)value {
	UIImage *uiImage = [[UIImage alloc] initWithData:value];
	return uiImage ;
}

@end
