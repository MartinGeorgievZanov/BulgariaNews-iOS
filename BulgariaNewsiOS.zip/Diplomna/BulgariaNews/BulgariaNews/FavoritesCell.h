//
//  FavoritesCell.h
//  BulgariaNews_iOS
//
//  Created by Makros on 3/11/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsObject.h"

@interface FavoritesCell : UITableViewCell
{
    NewsObject *news;
}

@property (strong, nonatomic) NewsObject *news;
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *newsDescription;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end
