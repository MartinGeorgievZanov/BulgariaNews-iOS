//
//  FavoritesDetailViewController.h
//  BulgariaNews
//
//  Created by Makros on 4/24/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FavoritesViewController.h"
#import "NewsObject.h"

@interface FavoritesDetailViewController : UIViewController
{
    NewsObject *news;
}

@property (nonatomic) IBOutlet UIButton * backButtonFavoritesDetail;

@property (strong, nonatomic) NewsObject *news;

@property (strong, nonatomic) IBOutlet UIWebView * favoritesWebView;

@end
