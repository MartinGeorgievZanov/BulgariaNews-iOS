//
//  AddedToFav.m
//  BulgariaNews
//
//  Created by Makros on 5/26/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import "AddedToFav.h"

@implementation AddedToFav

@dynamic id;

@end
