//
//  CurrencyViewController.h
//  BulgariaNews_iOS
//
//  Created by Makros on 3/11/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KMXMLParser.h"

@interface CurrencyViewController : UITableViewController <KMXMLParserDelegate> {
    
    int check;
}

@property (strong, nonatomic) NSMutableArray *parseResults;

@property (nonatomic) int check;

@end
