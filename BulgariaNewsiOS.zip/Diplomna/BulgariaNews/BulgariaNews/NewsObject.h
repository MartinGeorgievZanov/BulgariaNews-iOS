//
//  NewsObject.h
//  BulgariaNews_iOS
//
//  Created by Makros on 4/15/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@interface NewsObject : NSManagedObject

@property (nonatomic, retain) NSString * title;
@property (nonatomic, retain) NSString * news;
@property (nonatomic, retain) NSString * newsDescription;
@property (nonatomic, retain) NSString * dateEntered;
@property (nonatomic, retain) UIImage * image;
@property (nonatomic, retain) NSString * category;
@property (nonatomic, retain) NSString * imageLink;

@end

@interface ImageToDataTransformer : NSValueTransformer {
}
@end