//
//  HomeViewController.h
//  BulgariaNews_iOS
//
//  Created by Makros on 3/4/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KMXMLParser.h"
#import "NewsObject.h"
#import "MainViewController.h"

@interface HomeViewController : UICollectionViewController <KMXMLParserDelegate> {
    
    int check;
    int backCheck;
}

@property (strong, nonatomic) NSMutableArray *parseResults;
@property (nonatomic, strong) NSMutableArray *photos;
@property (nonatomic, strong) NSMutableArray *description;
@property (nonatomic) int check;

@end
