//
//  DetailViewController.h
//  BulgariaNews_iOS
//
//  Created by Makros on 3/4/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KMXMLParser.h"
#import "NewsObject.h"
#import "AddedToFav.h"

@interface NewsDetailViewController : UIViewController <KMXMLParserDelegate, UIScrollViewDelegate> {
    
    IBOutlet UIScrollView *scrollView;
    int check;
    NSMutableArray *parseCategories;
    BOOL checkIfCategoryIsOn;
    
    NSString * title2;
    NSString * newsDescription;
    NSString * summary;
    NSString * dateEntered;
    UIImage * image;
    NSString * category;
    NSString * imageLink;
    NSString * checkNews;
}

@property (nonatomic, retain) NSString * checkNews;

@property (nonatomic, retain) UIScrollView *scrollView;

@property (strong, nonatomic) NSMutableArray *parseResults;
@property (nonatomic) NSMutableArray *parseCategories;

@property (nonatomic) int check;
@property (nonatomic) BOOL checkIfCategoryIsOn;

@property (weak, nonatomic) IBOutlet UIWebView *detailNews;

@property (weak, nonatomic) IBOutlet UIImageView *detailImage;
@property (nonatomic) UIImage *img;

@property (strong, nonatomic) NewsObject *newsObject;

@property (nonatomic, retain) NSString * title2;
@property (nonatomic, retain) NSString * newsDescription;
@property (nonatomic, retain) NSString * summary;
@property (nonatomic, retain) NSString * dateEntered;
@property (nonatomic, retain) UIImage * image;
@property (nonatomic, retain) NSString * category;
@property (nonatomic, retain) NSString * imageLink;

@end
