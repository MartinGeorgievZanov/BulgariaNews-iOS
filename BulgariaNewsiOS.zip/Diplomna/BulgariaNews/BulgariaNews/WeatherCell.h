//
//  WeatherCell.h
//  BulgariaNews_iOS
//
//  Created by Makros on 3/11/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeatherCell : UITableViewCell

@property (nonatomic) IBOutlet UILabel * townName;
@property (nonatomic) IBOutlet UIWebView * webViewWeather;

@end
