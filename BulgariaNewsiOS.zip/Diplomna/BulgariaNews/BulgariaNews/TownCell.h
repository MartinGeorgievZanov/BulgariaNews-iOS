//
//  TownCell.h
//  BulgariaNews_iOS
//
//  Created by Makros on 3/11/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TownCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *townTitle;

@end
