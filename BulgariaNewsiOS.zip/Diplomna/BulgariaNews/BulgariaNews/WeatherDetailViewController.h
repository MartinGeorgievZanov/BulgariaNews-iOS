//
//  WeatherDetailViewController.h
//  BulgariaNews_iOS
//
//  Created by Makros on 3/11/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KMXMLParser.h"

@interface WeatherDetailViewController : UIViewController <KMXMLParserDelegate >{
    
    int check;
    NSString *link;
}

@property (strong, nonatomic) NSMutableArray *parseResults;

@property (nonatomic) int check;
@property (nonatomic) NSString *link;

@property (weak, nonatomic) IBOutlet UIWebView *webWeather1;

@end
