//
//  HomeViewController.m
//  BulgariaNews_iOS
//
//  Created by Makros on 3/4/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import "HomeViewController.h"
#import "HomeCell.h"
#import "NewsDetailViewController.h"
#import "MainViewController.h"

@interface HomeViewController ()

@property (nonatomic, strong) NSMutableArray * newsArray;
@property (nonatomic, strong) NSMutableDictionary *cachedImages;
@property (nonatomic) int countPictures;

@end

@implementation NSString (mycategory)

- (NSString *)stringByStrippingHTML
{
    NSRange r;
    NSString *s = [self copy];
    while ((r = [s rangeOfString:@"<[^>]+>" options:NSRegularExpressionSearch]).location != NSNotFound)
        s = [s stringByReplacingCharactersInRange:r withString:@""];
    return s;
}

@end

@implementation HomeViewController

@synthesize parseResults = _parseResults, check, photos, description, newsArray, countPictures,cachedImages;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    KMXMLParser *parser = [[KMXMLParser alloc] initWithURL:@"http://tony.tara-soft.net/xml" delegate:self];
    _parseResults = [parser posts];
    
    if(_parseResults.count < 1)
        [self parserDidFail];
    
    
    self.newsArray = [[NSMutableArray alloc] init];
    self.cachedImages = [[NSMutableDictionary alloc] init];
    
}



- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)reloadFeed {
    KMXMLParser *parser = [[KMXMLParser alloc] initWithURL:@"http://tony.tara-soft.net/xml" delegate:self];
    _parseResults = [parser posts];
    
    [self.collectionView reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.parseResults.count;
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *identifier = @"HomeCell";
    
    HomeCell *homeCell = (HomeCell *)[collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    
    if (homeCell == nil) {
        homeCell = (HomeCell *)[collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    }
    
    homeCell.title.text = [[self.parseResults objectAtIndex:indexPath.row] objectForKey:@"title"];
    
    homeCell.newsImage.image = nil;
    
    NSString *identifier2 = [NSString stringWithFormat:@"%d" ,
                            indexPath.row];
    
    if([self.cachedImages objectForKey:identifier] != nil){
        homeCell.newsImage.image = [self.cachedImages valueForKey:identifier2];
        
    }else{
        
        char const * s = [identifier2  UTF8String];
        
        dispatch_queue_t queue = dispatch_queue_create(s, 0);
        
        dispatch_async(queue, ^{
            
            NSString *urlS = [[self.parseResults objectAtIndex:indexPath.row] objectForKey:@"link"];
            
            urlS = [urlS stringByReplacingOccurrencesOfString:@" " withString:@""];
            urlS = [urlS stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            urlS = [urlS stringByReplacingOccurrencesOfString:@"\t" withString:@""];
            
                UIImage *img = nil;
            
            NSData *dataSD = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:[ NSString stringWithFormat:@"%@",urlS]]];
            
        
            img = [[UIImage alloc] initWithData:dataSD];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if ([collectionView indexPathForCell:homeCell].row == indexPath.row) {
                    
                    [self.cachedImages setValue:img forKey:identifier2];
                    homeCell.newsImage.image = [self.cachedImages   valueForKey:identifier2];
                }
            });
        });
        
    }
    
    return homeCell;
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([segue.identifier isEqualToString:@"homeToDetail"]){
        HomeCell *cell = (HomeCell *)sender;
        NSIndexPath *indexPath = [self.collectionView indexPathForCell:cell];
        check = indexPath.row;
        NewsDetailViewController* detail =
        (NewsDetailViewController*)[segue destinationViewController];
        detail.check = check;
    }
}

- (void)parserDidFail{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Could not parse feed. Check your network connection." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

- (void)parserDidFailWithError:(NSError *)error {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Could not parse feed. Check your network connection." delegate:self cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
    [alert show];
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

- (void)parserCompletedSuccessfully {
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

- (void)parserDidBegin {
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
}

@end
