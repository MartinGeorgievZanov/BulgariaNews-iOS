//
//  DetailViewController.m
//  BulgariaNews_iOS
//
//  Created by Makros on 3/4/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import "NewsDetailViewController.h"
#import "MainViewController.h"
#import "AppDelegate.h"

@interface NewsDetailViewController ()

@end

@implementation NSString (mycategory)

- (NSString *)stringByStrippingHTML
{
    NSRange r;
    NSString *s = [self copy];
    while ((r = [s rangeOfString:@"<[^>]+>" options:NSRegularExpressionSearch]).location != NSNotFound)
        s = [s stringByReplacingCharactersInRange:r withString:@""];
    return s;
}

@end

@implementation NewsDetailViewController

@synthesize parseResults = _parseResults;
@synthesize check, scrollView ,checkIfCategoryIsOn, detailNews, newsObject, title2, summary, newsDescription, dateEntered, category, image, imageLink, checkNews, detailImage, parseCategories;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (NSManagedObjectContext *)managedObjectContext {
    NSManagedObjectContext *context = nil;
    id delegate = [[UIApplication sharedApplication] delegate];
    if ([delegate performSelector:@selector(managedObjectContext)]) {
        context = [delegate managedObjectContext];
    }
    return context;
}

- (void)buttonSaveToFavorites:(id)sender {
    NSManagedObjectContext *context = [self managedObjectContext];
    NSMutableArray * mutableArr = [[NSMutableArray alloc] init];
    AppDelegate* appDelegate = [UIApplication sharedApplication].delegate;
    
    // Fetching Records and saving it in "fetchedRecordsArray" object
    [mutableArr addObjectsFromArray:[appDelegate  getAllNews]];
    int checkEqual=0;
    for (int a=0;a<mutableArr.count;a++){
        NewsObject * object = [mutableArr objectAtIndex:a];
        if([object.title isEqualToString:title2]){
            checkEqual = 1;
        }
        
    }
    if(checkEqual == 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"You added this news to your Favorites!" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        NewsObject *newObject = [NSEntityDescription insertNewObjectForEntityForName:@"NewsObject"
                                                              inManagedObjectContext:context];
        
        newObject.title = title2;
        newObject.newsDescription = summary;
        newObject.image = image;
        newObject.dateEntered = dateEntered;
        newObject.news = newsDescription;
        newObject.category = category;
        newObject.imageLink = imageLink;
        
        [alert show];
        
    } else if (checkEqual == 1) {
        NSString *massageStr = [NSString stringWithFormat:@"You have already added this news to your Favorites!"];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:massageStr delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alert show];
    }
    
        NSError *error = nil;
        // Save the object to persistent store
        if (![context save:&error]) {
            NSLog(@"Can't Save! %@ %@", error, [error localizedDescription]);
        }

    [self dismissViewControllerAnimated:YES completion:nil];
    
    //self.saveToFavorites.hidden = YES;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(buttonSaveToFavorites:)];
    self.navigationItem.rightBarButtonItem = addButton;
    
//    MainViewController *mainView = [[MainViewController alloc] init];
//    
//    mainView.backButtonNewsDetails = [UIButton buttonWithType:UIButtonTypeCustom];
//    
//    mainView.backButtonNewsDetails.hidden = NO;
//    [mainView.backButtonNewsDetails addTarget:self action:@selector(revealMenu:) forControlEvents:UIControlEventTouchUpInside];
    
    //self.saveToFavorites.hidden = NO;
    
    scrollView.delegate = self;
    self.scrollView.contentMode = UIViewContentModeScaleToFill;
    scrollView.clipsToBounds = YES;

    
    KMXMLParser *parser = [[KMXMLParser alloc] initWithURL:@"http://tony.tara-soft.net/xml" delegate:self];
    _parseResults = [parser posts];
    //http://sinoptik.bg/rss/100727011
    
    [self stripHTMLFromSummary];
    
    if (checkIfCategoryIsOn == YES) {
        NSString * ALL;
        
        newsDescription = [[self.parseCategories objectAtIndex:check ] objectForKey:@"newsDescription"];
        
        dateEntered = [[self.parseCategories objectAtIndex:check] objectForKey:@"date"];

        title2 = [[self.parseCategories objectAtIndex:check] objectForKey:@"title"];
        
        summary = [[self.parseCategories objectAtIndex: check] objectForKey:@"summary"];
        
        category = [[self.parseCategories objectAtIndex: check] objectForKey:@"category"];
        
        imageLink = [[self.parseCategories objectAtIndex: check] objectForKey:@"link"];
        
        NSString *string = imageLink;
        string = [string stringByReplacingOccurrencesOfString:@" " withString:@""];
        string = [string stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        string = [string stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        NSLog(@"Picture : %@", string);
        NSData * data = [[NSData alloc] init];
        data = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:[ NSString stringWithFormat:@"%@",string]]];
        image = [UIImage imageWithData: data];
//        self.detailImage.image = img;
        
        
        ALL =[NSString stringWithFormat:@"<div style=\"background-color:#E6D6BD\"></br><h3 style=\"position:block; margin-left:25%\" color=\"black\" width=\"250\">%@</h3><font style=\"position:block; margin-left:25%\" color=\"black\" width=\"250\">%@</font></br></br><img style=\"position:block; margin-left:25%\" src=\"%@\" height=\"200\" width=\"270\"/></br></br><div style=\"position:block; margin-left:10%; margin-right:10%\" color=\"black\" width=\"300\">%@</font></div></br></div>", title2, dateEntered, imageLink, newsDescription];
        
        [detailNews loadHTMLString:ALL baseURL:nil];
        
//        NSManagedObjectContext *context = [self managedObjectContext];
        
//        // Create a new device
//        
        
//        detailDateEntered.text = [[self.parseCategories objectAtIndex:check] objectForKey:@"date"];
    } else {
    NSString * ALL;
    
        newsDescription = [[self.parseResults objectAtIndex: check ] objectForKey:@"newsDescription"];
        
        dateEntered = [[self.parseResults objectAtIndex: check] objectForKey:@"date"];
        
        title2 = [[self.parseResults objectAtIndex: check] objectForKey:@"title"];
        
        summary = [[self.parseResults objectAtIndex: check] objectForKey:@"summary"];
        
        imageLink = [[self.parseResults objectAtIndex: check] objectForKey:@"link"];
        
        category = [[self.parseResults objectAtIndex: check ] objectForKey:@"category"];
        
        
        //NSString * picString;

        
        NSString *string = imageLink;
        string = [string stringByReplacingOccurrencesOfString:@" " withString:@""];
        string = [string stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        string = [string stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        NSLog(@"Picture : %@", string);
        
        NSData * data = [[NSData alloc] init];
        data = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:[ NSString stringWithFormat:@"%@",string]]];
        image = [UIImage imageWithData: data];
//    img = [UIImage imageWithData: data];
//    self.detailImage.image = img;
    
    ALL =[NSString stringWithFormat:@"<div style=\"background-color:#E6D6BD\"></br><h3 style=\"position:block; margin-left:25%\" color=\"black\" width=\"250\">%@</h3><font style=\"position:block; margin-left:25%\" color=\"black\" width=\"250\">%@</font></br></br><img style=\"position:block; margin-left:25%\" src=\"%@\" height=\"200\" width=\"270\"/></br></br><div style=\"position:block; margin-left:10%; margin-right:10%\" color=\"black\" width=\"300\">%@</font></div></br></div>", title2, dateEntered, imageLink, newsDescription];
        
//    ALL =[NSString stringWithFormat:@"<div style=\"background-color:#E6B6BD\"><font color=\"black\"><h4>%@</h4></font><font color=\"black\">%@</font></br></br><img src=\"%@\" height=\"200\" width=\"270\"/></br></br>%@</br></div>", title2, dateEntered, imageLink, newsDescription];
    
    [detailNews loadHTMLString:ALL baseURL:nil];
        
    }
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)stripHTMLFromSummary {
    int i = 0;
    int count = self.parseResults.count;
    //cycles through each 'summary' element stripping HTML
    while (i < count) {
        NSString *tempString = [[self.parseResults objectAtIndex:i] objectForKey:@"summary"];
        NSString *string = tempString;
        string = [string stringByReplacingOccurrencesOfString:@"&nbsp;" withString:@""];
        //NSString *strippedString = [string stringByStrippingHTML];
        NSMutableDictionary *dict = [self.parseResults objectAtIndex:i];
        [dict setObject:string forKey:@"summary"];
        [self.parseResults replaceObjectAtIndex:i withObject:dict];
        i++;
    }
}

- (void)reloadFeed {
    KMXMLParser *parser = [[KMXMLParser alloc] initWithURL:@"http://tony.tara-soft.net/xml" delegate:self];
    _parseResults = [parser posts];
    
    [self stripHTMLFromSummary];
    //[self.view reloadData];
}

#pragma mark - KMXMLParser Delegate

- (void)parserDidFailWithError:(NSError *)error {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Could not parse feed. Check your network connection." delegate:self cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
    [alert show];
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

- (void)parserCompletedSuccessfully {
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

- (void)parserDidBegin {
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)revealMenu:(id)sender
{

}


@end
