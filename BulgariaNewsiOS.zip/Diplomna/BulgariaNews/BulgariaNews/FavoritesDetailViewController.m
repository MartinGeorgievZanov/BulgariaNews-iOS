//
//  FavoritesDetailViewController.m
//  BulgariaNews
//
//  Created by Makros on 4/24/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import "FavoritesDetailViewController.h"

@interface FavoritesDetailViewController ()

@end

@implementation FavoritesDetailViewController

@synthesize news, favoritesWebView, backButtonFavoritesDetail;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    NSString * ALL;
    
    NSString *string = news.imageLink;
    string = [string stringByReplacingOccurrencesOfString:@" " withString:@""];
    string = [string stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    string = [string stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    NSLog(@"Picture - %@", string);
    
    ALL =[NSString stringWithFormat:@"<div style=\"background-color:#E6D6BD\"><h4 style=\"position:block; margin-left:25%\" color=\"black\" width=\"250\">%@</h4><font style=\"position:block; margin-left:25%\" color=\"black\" width=\"250\">%@</font></br></br><img style=\"position:block; margin-left:25%\" src=\"%@\" height=\"200\" width=\"270\"/></br></br><div style=\"position:block; margin-left:10%; margin-right:10%\" color=\"black\" width=\"300\">%@</font></div></br></div>", news.title, news.dateEntered, string, news.news];
    
    [favoritesWebView loadHTMLString:ALL baseURL:nil];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
