//
//  CategoriesViewController.m
//  BulgariaNews_iOS
//
//  Created by Makros on 3/3/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import "CategoriesViewController.h"
#import "CategoriesCell.h"
#import "NewsDetailViewController.h"
#import "ECSlidingViewController.h"

@interface CategoriesViewController ()

@property (nonatomic, strong) NSMutableArray * newsArray;

@end

@implementation NSString (mycategory)

- (NSString *)stringByStrippingHTML
{
    NSRange r;
    NSString *s = [self copy];
    while ((r = [s rangeOfString:@"<[^>]+>" options:NSRegularExpressionSearch]).location != NSNotFound)
        s = [s stringByReplacingCharactersInRange:r withString:@""];
    return s;
}

@end

@implementation CategoriesViewController
@synthesize parseResults = _parseResults;
@synthesize parseSecond = _parseSecond;
@synthesize title, description, check, parseCategories, categoryName, checkIfCategoryIsOn, newsArray;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //Parse feed
    KMXMLParser *parser = [[KMXMLParser alloc] initWithURL:@"http://tony.tara-soft.net/xml" delegate:self];
    _parseResults = [parser posts];
    
    self.newsArray = [[NSMutableArray alloc] init];
    
    parseCategories = [[NSMutableArray alloc] init];
    
    NSString *name;
    for (int i = 0; i<self.parseResults.count; i++) {
        name = [[self.parseResults objectAtIndex:i ] objectForKey:@"category"];
        
        NSString *string = name;
        //NSMutableArray *parseCategories;
        string = [string stringByReplacingOccurrencesOfString:@" " withString:@""];
        string = [string stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        string = [string stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        
        if ([string isEqualToString:categoryName]) {
            [parseCategories addObject:[_parseResults objectAtIndex:i]];
        }
    }
    
    for (int i = 0; i < parseCategories.count; i++) {
        NSData * data = [[NSData alloc] init];
        
        NSString * picString;
        picString = [[self.parseCategories objectAtIndex:i] objectForKey:@"link"];
        
        picString = [picString stringByReplacingOccurrencesOfString:@" " withString:@""];
        picString = [picString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        picString = [picString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        
        data = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:[ NSString stringWithFormat:@"%@",picString]]];
        
        [newsArray addObject:data];
    }
    
    [self stripHTMLFromSummary];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)stripHTMLFromSummary {
    int i = 0;
    int count = self.parseResults.count;
    //cycles through each 'summary' element stripping HTML
    while (i < count) {
        NSString *tempString = [[self.parseResults objectAtIndex:i] objectForKey:@"summary"];
        NSString *string = tempString;
        string = [string stringByReplacingOccurrencesOfString:@"&nbsp;" withString:@""];
        NSString *strippedString = [string stringByStrippingHTML];
        NSMutableDictionary *dict = [self.parseResults objectAtIndex:i];
        [dict setObject:strippedString forKey:@"summary"];
        [self.parseResults replaceObjectAtIndex:i withObject:dict];
        i++;
    }
}

- (void)reloadFeed {
    KMXMLParser *parser = [[KMXMLParser alloc] initWithURL:@"http://tony.tara-soft.net/xml" delegate:self];
    _parseResults = [parser posts];
    
    [self stripHTMLFromSummary];
    [self.tableView reloadData];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return self.parseCategories.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *CellIdentifier = @"Cell";
    CategoriesCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    //Check if cell is nil. If it is create a new instance of it
    if (cell == nil) {
        cell = [[CategoriesCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    cell.cellImage.image = nil;
    
    cell.cellTitle.text = [[self.parseCategories objectAtIndex:indexPath.row] objectForKey:@"title"];
    cell.cellTitle.numberOfLines = 2;
    //Configure detailTitleLabel
    cell.cellDescription.text = [[self.parseCategories objectAtIndex:indexPath.row] objectForKey:@"date"];
    cell.cellDescription.numberOfLines = 1;
    //Set accessoryType
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    dispatch_async(dispatch_get_global_queue(0,0), ^{
        int asd = indexPath.row;
        if ([newsArray objectAtIndex:asd]){
            UIImage *imageS = [UIImage imageWithData: [newsArray objectAtIndex:asd]];
            if(imageS){
                dispatch_async(dispatch_get_main_queue(), ^{
                    CategoriesCell *updateCell = (id)[tableView cellForRowAtIndexPath:indexPath];
                    if(updateCell)
                        cell.cellImage.image = imageS;
                });
            }
        }
    });
    return cell;
}

#pragma mark - Table view delegate

//- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    check = indexPath.row;
//}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([segue.identifier isEqualToString:@"categoriesToDetail"]){
        NSIndexPath *indexPath = self.tableView.indexPathForSelectedRow;
        check = indexPath.row;
        checkIfCategoryIsOn = YES;
        NewsDetailViewController* detail =
        (NewsDetailViewController*)[segue destinationViewController];
        detail.check = check;
        detail.parseCategories = parseCategories;
        detail.checkIfCategoryIsOn = checkIfCategoryIsOn;
        NSLog(@"ASD CHECK : %d", check);
    }
}

#pragma mark - KMXMLParser Delegate

- (void)parserDidFailWithError:(NSError *)error {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Could not parse feed. Check your network connection." delegate:self cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
    [alert show];
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

- (void)parserCompletedSuccessfully {
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

- (void)parserDidBegin {
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
}

@end
