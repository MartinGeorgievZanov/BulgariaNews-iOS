//
//  HomeCell.m
//  BulgariaNews_iOS
//
//  Created by Makros on 3/5/14.
//  Copyright (c) 2014 MartinZanov. All rights reserved.
//

#import "HomeCell.h"

@implementation HomeCell

@synthesize title,newsImage;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

@end
